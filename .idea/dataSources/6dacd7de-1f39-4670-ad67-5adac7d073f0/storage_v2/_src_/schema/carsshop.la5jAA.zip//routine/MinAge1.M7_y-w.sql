create
    definer = root@localhost function MinAge1(mark varchar(20)) returns int deterministic
BEGIN


    RETURN (SELECT  Min(clients.age) FROM clients 
            INNER JOIN orders  ON orders.client_id = clients.id
			INNER JOIN cars  ON cars.id = orders.car_id 
            INNER JOIN marks  ON marks.id = cars.mark_id  WHERE marks.mark = mark  ); 
            
	END;

