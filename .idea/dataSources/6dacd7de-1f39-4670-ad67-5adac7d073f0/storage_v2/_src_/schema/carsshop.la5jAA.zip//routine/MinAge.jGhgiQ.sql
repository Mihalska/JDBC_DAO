create
    definer = root@localhost function MinAge() returns int deterministic
BEGIN
    RETURN (SELECT MIN(age) FROM clients );   
	END;

